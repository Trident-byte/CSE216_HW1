interface Shape{
    Point center = null;
    public Point center();
    public double area();
}