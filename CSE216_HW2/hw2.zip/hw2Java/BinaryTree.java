public class BinaryTree<T extends Number> {
}
